# RajatPatwari.Vertex
A new high-level stack-based assembly-like programming language interpreted by .NET Core.

### Version 2.0
Vertex `v2.0.1` was just released! Check Releases or `CHANGELOG.md` for more information.

### Notes
__Framework:__ .NET Core 3.1

__Author:__ Rajat Patwari

__License:__ BSD 3-Clause